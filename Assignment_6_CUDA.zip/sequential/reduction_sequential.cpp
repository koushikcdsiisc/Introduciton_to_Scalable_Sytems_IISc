#include<iostream>
#include <stdio.h>
#include <fstream>
#include <chrono>

using namespace std;

int main(){

    //Read from the input file
	fstream file("reduce_data.txt");
	int a;
	int i;
	int n = 20000;
	int sum=0;
	int array[20000];

	//load from the file
	ifstream infile;
    infile.open("merge_data.txt");
	for(i=0;i<n;i++){
	file >> a;
	array[i] = a;
	}
	infile.close();
	//Start time
	auto start = chrono::high_resolution_clock::now();
	for(i=0;i<n;i++){
	sum += array[i];
	}
	//End time
	auto finish = chrono::high_resolution_clock::now();   //Insertion time clock ends here
    chrono::duration<double> elapsed = finish - start;
    cout <<"Elapsed total time by sequential code in miliseconds:"<< (elapsed.count() *1000.0)<<endl;
    cout<<"Total sum after reduction is:"<<sum;


    return 0;

}

