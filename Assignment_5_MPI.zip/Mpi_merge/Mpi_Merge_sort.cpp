#include <stdio.h>
#include<iostream>
#include <stdlib.h>
#include <time.h>
#include <mpi.h>
#include <fstream>
using namespace std;


void merge(int L[],int R[],int arr[],int n1,int n2) 
{ 
    int i, j, k; 
    i = 0; // Initial index of first subarray 
    j = 0; // Initial index of second subarray 
    k = 0; // Initial index of merged subarray 
    while (i < n1 && j < n2) 
    { 
        if (L[i] <= R[j]) 
        { 
            arr[k] = L[i]; 
            i++; 
        } 
        else
        { 
            arr[k] = R[j]; 
            j++; 
        } 
        k++; 
    } 
  
    /* Copy the remaining elements of L[], if there are any */
    while (i < n1) 
    { 
        arr[k] = L[i]; 
        i++; 
        k++; 
    } 
  
    /* Copy the remaining elements of R[], if there are any */
    while (j < n2) 
    { 
        arr[k] = R[j]; 
        j++; 
        k++; 
    } 
}

static int compare (const void * a, const void * b)
	{
	  return ( *(int *)a -*( int *)b );  //If key for a is > key for b return a positive number else neagtive
	}
			


int main(int argc, char** argv){
  
  
  //Size of input array
  int n = 100000;
  int i = 0; 
  int newarrsize;
  //Initialize MPI
  MPI_Init(&argc, &argv);
  double start ;
  int myrank, worldsize, len;
  MPI_Comm comm = MPI_COMM_WORLD;

  MPI_Comm_rank(comm, &myrank);
  MPI_Comm_size(comm, &worldsize);
  
  //Divide the array
  int size = n / worldsize;
  newarrsize = size;
  
  //Allocate sub-arrays to each of the processes
  int *sub_array; 
  if(myrank == 0){
  	sub_array = (int *)malloc( ((n%worldsize)+size) * sizeof( int ) );
  }
  else{
  	sub_array = (int *)malloc( size * sizeof( int ) );
  }
  
  
  //Loading the whole array in process 0
   int *comp_array;
   int *temp_array;
   
  if(myrank == 0) { 

    comp_array = (int *)malloc( n * sizeof( int ) );

    //Read from the input file
		fstream file("merge_data.txt");
		int a;
		int i;

		for(i=0;i<n;i++){
  		file >> a;
  		comp_array[i] = a;
		}
		//Start to measure time for process 0
		start = MPI_Wtime();

      temp_array = sub_array;

	  for(i=0;i<(n%worldsize);i++){
  		sub_array[i]=comp_array[i];
  		newarrsize++;
	  }

    sub_array = sub_array + (n%worldsize);
    comp_array = comp_array + (n%worldsize);
  }

  MPI_Scatter(comp_array,size,MPI_INT,sub_array,size,MPI_INT,0,comm);

  if(myrank == 0){
    sub_array = temp_array;
  }


  qsort (sub_array, newarrsize , sizeof(int), compare); 
  

  int jump = 1;
      do{
  	
      		if(myrank % (jump*2) == jump){
    	    	MPI_Send(sub_array,(newarrsize),MPI_INT,(myrank-jump),1,comm);
    		  }

    		  if(myrank % (jump*2) == 0 && (myrank+jump)<worldsize){
        		//For receiving the right sub array
        		MPI_Status status;
        		int cnt_ele;
          		int *right_sub_array; 
          		right_sub_array = (int *)malloc( (size*jump) * sizeof( int ) );
          		MPI_Recv(right_sub_array,(size*jump),MPI_INT,(myrank+jump),1,comm,&status);
      		    MPI_Get_count(&status, MPI_INT, &cnt_ele);	

          		//For merging the two sub-arrays
          		int *temp_array; 
          		temp_array = (int *)malloc( (newarrsize	+ cnt_ele) * sizeof( int ) );
          		merge(sub_array,right_sub_array,temp_array,newarrsize,cnt_ele);

      		    newarrsize = newarrsize	+ cnt_ele;
          		//Copy it as the main sub-array
      			sub_array = temp_array;
      			free(right_sub_array);	
  	      }
		      jump = jump*2;
	}while(((float)worldsize/jump) > 1);

	if(myrank == 0){
	  //end the time measure for process 0
	  double end = MPI_Wtime();
      cout << "The process took " << (end - start)*1000 << " mili-seconds to run." << endl;

      ofstream file("sorted_data.txt");
      for(i=0;i<n;i++){
        file << sub_array[i];
        file << '\n';
      }
	}
    
  MPI_Finalize();
 
  return 0;
}
