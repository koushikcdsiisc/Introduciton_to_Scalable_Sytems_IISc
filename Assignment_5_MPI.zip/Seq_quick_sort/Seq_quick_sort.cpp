#include <stdio.h>
#include<iostream>
#include <stdlib.h>
#include <time.h>
#include <fstream>
using namespace std;


static int compare (const void * a, const void * b)
	{
	  return ( *(int *)a -*( int *)b );  //If key for a is > key for b return a positive number else neagtive
	}



int main(){
  
  
  //Size of input array
  int n = 100000;
  int newarrsize;
  int a;
  int i;
  int *comp_array;
  comp_array = (int *)malloc( n * sizeof( int ) );
  ifstream infile;
  infile.open("merge_data.txt");
  for(i=0;i<n;i++){
    infile >> a;
    comp_array[i] = a;
  }
  infile.close();
  clock_t start, end;
  double cpu_time_used;
  start = clock();

  qsort (comp_array, n , sizeof(int), compare); 

  end = clock();
  cpu_time_used = ((double) (end - start)) / CLOCKS_PER_SEC;
  cout << "The sequential process took " << cpu_time_used << " seconds to run." << endl;
  ofstream outfile;
  outfile.open("seq_sorted_data.txt");
  for(i=0;i<n;i++){
  outfile << comp_array[i];
  outfile << '\n';
	}
  outfile.close();
  return 0;

}
