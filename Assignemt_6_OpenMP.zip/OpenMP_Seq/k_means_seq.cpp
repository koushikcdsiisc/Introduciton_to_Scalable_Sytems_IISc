#include<iostream>
#include <cstdlib>
#include <string>
#include <chrono>
#include <stdlib.h>
#include <stdio.h>
#include <fstream>
#include <istream>
#include <sstream>
#define N_OBJ 500000   ///To be modified
#define N_CLUSTER 20
#define DIM 2
using namespace std;
static double objects[N_OBJ][DIM];
static double clusters[N_CLUSTER][DIM];
static int member_idx[N_OBJ];
static double update_clusters_sum[N_CLUSTER][DIM];
static int update_clusters_size[N_CLUSTER];
static int final_clusters_size[N_CLUSTER];

float distance(float x1, float y1 , float x2 , float y2){
    float dist=0.0;
    dist =  ((x1-x2)*(x1-x2)) + ((y1-y2)*(y1-y2));
    return(dist);
}

int find_nearest_cluster(int obj_index) 
{
    int   index, i;
    float dist, min_dist;
    index    = 0;
    min_dist = distance(objects[obj_index][0],objects[obj_index][1],clusters[0][0],clusters[0][1]);
    for (i=1; i<N_CLUSTER; i++) {
        dist = distance(objects[obj_index][0],objects[obj_index][1],clusters[i][0],clusters[i][1]);
        if (dist < min_dist) {
            min_dist = dist;
            index    = i;
        }
    }
    return(index);
}


int main()
{   

	
	int i =0;
	int j;
	int update_cnt = 0;
	int index;
	int max_change_allowed = 0; //To be modified as per accuracy required
	int loopcount = 0;
	int random;
    //Load the objects from the CSV file
	ifstream ifs ;
	string line;
 	ifs.open("data_500k.csv");	///To be modified
	if (ifs.is_open()){
	    while (getline(ifs, line)) {		//read a line
		stringstream ss(line);
		string str;
	    getline(ss, str, ',');		       
        objects[i][0] = stoi(str);       
	    getline(ss, str, ',');	           //read the value
		objects[i][1] = stoi(str);
		i++;						
		}	
	}	
	else
	throw invalid_argument("Unable to open file");
	ifs.close();
	

	auto start = chrono::high_resolution_clock::now();
    
    random  = (rand() % (N_OBJ/N_CLUSTER));
    for (i=0; i<N_CLUSTER; i++){
    for (j=0; j<DIM; j++){        	
        clusters[i][j] = objects[random][j];
    }
    random = random + (N_OBJ/N_CLUSTER);
    }
    
    
    //Initially all cluster index for the data points are set to -1
	for (i=0; i<N_OBJ; i++) 
		member_idx[i] = -1;

    do{
		update_cnt = 0;
	    for (i=0; i<N_OBJ; i++) {
	        //To find the nearest cluster index for the objects
	        index = find_nearest_cluster(i);
	        // To keep track of the no of objects for which cluster index is changing in a loop
	        if (member_idx[i] != index) 
				update_cnt += 1.0;
			// Cluster Index is updated
			member_idx[i] = index;
	        //To keep Track of the number of elements and their sum in each cluster group as new index is calculated for each object
	        update_clusters_size[index]++;
	        for (j=0; j<DIM; j++)
	            update_clusters_sum[index][j] += objects[i][j];
	    }
	    //To find the new cluster centres based on updates in the cluster objects
	    for (i=0; i<N_CLUSTER; i++) {
	    	for (j=0; j<DIM; j++) {
	    		if(update_clusters_size[i]>0){
	            clusters[i][j] = update_clusters_sum[i][j] / update_clusters_size[i];
	            }
	        	update_clusters_sum[i][j] = 0.0;
	    }
	    final_clusters_size[i] = update_clusters_size[i];
	    update_clusters_size[i] = 0.0;
	    }	    
		loopcount++;
    } while (update_cnt > max_change_allowed && loopcount < 500);
    
	for (i=0; i<N_CLUSTER; i++){
		cout<<i<<'\t'<<final_clusters_size[i]<<'\t';
        for (j=0; j<DIM; j++){        	
            cout<<clusters[i][j]<<'\t'<<'\t';
        }
    	cout<<endl;
	}
	auto finish = chrono::high_resolution_clock::now();   //Insertion time clock ends here
    chrono::duration<double> elapsed = finish - start;
    cout <<"Elapsed total time by sequential code in miliseconds:"<< (elapsed.count() *1000.0);	
    
    //debug if elements read or not
	ofstream myfile;
	myfile.open("clusters_seq.csv");
    if (myfile.is_open())
    {  
	for (i=0; i<N_CLUSTER; i++){
    		myfile << clusters[i][0];
			myfile << ",";
			myfile << clusters[i][1];
    		myfile << "\n";	
		}
    myfile.close();
    }
    else cout << "Unable to open file";
	   
	return 0;	
}

